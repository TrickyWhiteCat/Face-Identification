
import sys
import os
sys.path.append(os.path.join(os.path.abspath(os.path.pardir),"face detection and alignment"))
sys.path.append(os.path.join(os.path.abspath(os.path.pardir),"face detection and alignment"))
from Detection.MtcnnDetector import MtcnnDetector
from Detection.detector import Detector
from Detection.fcn_detector import FcnDetector
from train_models.mtcnn_model import P_Net, R_Net, O_Net
from prepare_data.loader import TestLoader
import cv2
import os
import numpy as np
import math
from array import array
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"

test_mode = "ONet"
thresh = [0.7, 0.8, 0.8]
min_face_size = 20
stride = 2
slide_window = False
shuffle = False
detectors = [None, None, None]
prefix = ['C:/Users/data_/MTCNN_model/PNet_landmark/PNet', 'C:/Users/data_/MTCNN_model/RNet_No_landmark/RNet', 'C:/Users/data_/MTCNN_model/ONet_landmark/ONet']
epoch = [18, 14, 16]
#batch_size = [2048, 64, 16]
batch_size = [1, 1, 1]
model_path = ['%s-%s' % (x, y) for x, y in zip(prefix, epoch)]
# load pnet model
if slide_window:
    PNet = Detector(P_Net, 12, batch_size[0], model_path[0])
else:
    PNet = FcnDetector(P_Net, model_path[0])
detectors[0] = PNet

# load rnet model
if test_mode in ["RNet", "ONet"]:
    RNet = Detector(R_Net, 24, batch_size[1], model_path[1])
    detectors[1] = RNet

# load onet model
if test_mode == "ONet":
    ONet = Detector(O_Net, 48, batch_size[2], model_path[2])
    detectors[2] = ONet

mtcnn_detector = MtcnnDetector(detectors=detectors, min_face_size=min_face_size,
                               stride=stride, threshold=thresh, slide_window=slide_window)
image = cv2.imread(r'C:\Users\Laptop K1\Downloads/414482776_742721691081066_164190456155542150_n.jpg')


#all_boxes,landmarks = mtcnn_detector.detect_face(test_data)
import time
start = time.time()
all_boxes,landmarks = mtcnn_detector.detect_single_image(image)
print(time.time()-start)
normal_matrix = [[list(box) for box in boxes] for boxes in all_boxes][0]
max=0
a=normal_matrix[0]
max_area=math.fabs(a[2]-a[0])*math.fabs(a[3]-a[1])
for i in range(1,len(normal_matrix)):
   b=normal_matrix[i]
   if max_area<math.fabs(b[2]-b[0])*math.fabs(b[3]-b[1]):
      max_area=math.fabs(b[2]-b[0])*math.fabs(b[3]-b[1])
      max=i   
landmarks=list(array('f', landmarks[0][max]))
all_boxes=list(array('f', all_boxes[0][max]))
left_eye_x=landmarks[0]
left_eye_y=landmarks[1]
right_eye_x=landmarks[2]
right_eye_y=landmarks[3]
if left_eye_y > right_eye_y:
   point_3rd = (right_eye_x, left_eye_y)
   direction = -1 #rotate same direction to clock
   print("rotate to clock direction")
else:
   point_3rd = (left_eye_x, right_eye_y)
   direction = 1 #rotate inverse direction of clock
   print("rotate to inverse clock direction")
def euclidean_distance(a, b):
  x1 = a[0]; y1 = a[1]
  x2 = b[0]; y2 = b[1]
  return math.sqrt(((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)))
a = euclidean_distance((left_eye_x,left_eye_y), point_3rd)
b = euclidean_distance((right_eye_x,right_eye_y), (left_eye_x,left_eye_y))
c = euclidean_distance((right_eye_x,right_eye_y), point_3rd)
cos_a = (b*b + c*c - a*a)/(2*b*c)
print("cos(a) = ", cos_a)

angle = np.arccos(cos_a)
print("angle: ", angle," in radian")

angle = (angle * 180) / math.pi
print("angle: ", angle," in degree")
if direction == -1:
   angle = 90 - angle
from PIL import Image
image= Image.fromarray(image)
image = np.array(image.rotate(direction * angle))
import time
start = time.time()
all_boxes,landmarks = mtcnn_detector.detect_single_image(image)
print(time.time()-start)
print(len(all_boxes),all_boxes[0].shape)
print(len(landmarks),landmarks[0].shape)   
count = 0
#cv2.imshow("lala",image)
#cv2.waitKey(0)   
normal_matrix = [[list(box) for box in boxes] for boxes in all_boxes][0]
max=0
a=normal_matrix[0]
max_area=math.fabs(a[2]-a[0])*math.fabs(a[3]-a[1])
for i in range(1,len(normal_matrix)):
   b=normal_matrix[i]
   if max_area<math.fabs(b[2]-b[0])*math.fabs(b[3]-b[1]):
      max_area=math.fabs(b[2]-b[0])*math.fabs(b[3]-b[1])
      max=i
# Display the normal matrix
print(normal_matrix)
print(all_boxes)
landmarks=list(array('f', landmarks[0][max]))
all_boxes=list(array('f', all_boxes[0][max]))
y1 = int(all_boxes[1])
y2 = int(all_boxes[3])
x1 = int(all_boxes[0])
x2 = int(all_boxes[2])

# Extract the bounding box region from the image
bbox_image = image[y1:y2, x1:x2]

cv2.imshow("lala",bbox_image)
cv2.waitKey(0)  
bbox_image_pil = Image.fromarray(bbox_image)

# Save the PIL Image as 'Hương_1.jpg'
#cv2.imwrite(r'C:/Users/Laptop K1/Downloads/Hương_1.jpg', bbox_image_pil)
#bbox_image_pil.save(r'C:/Users/Laptop K1/Downloads/Hương_1.jpg')
cv2.imwrite(r'C:/Users/Laptop K1/Downloads/8.jpg',bbox_image)
cv2.waitKey(0) 


        
            
